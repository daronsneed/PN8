import { PromptBuilder } from '@/components/prompt-builder';

const Index = () => {
  return <PromptBuilder />;
};

export default Index;
